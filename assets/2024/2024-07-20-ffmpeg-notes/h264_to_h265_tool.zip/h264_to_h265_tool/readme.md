# 环境说明

## ffmpeg

视频处理用，给h264toh265.bat（archive）和youtube-dl用。

[github链接](https://github.com/FFmpeg/FFmpeg) [官网链接](https://ffmpeg.org/)

## exiftool

处理视频metadata用。

[github链接](https://github.com/exiftool/exiftool) [官网链接](https://exiftool.org/)

## youtube-dl

下载视频用。

[github链接](https://github.com/ytdl-org/youtube-dl) [官网链接](http://ytdl-org.github.io/youtube-dl/)

但是好像最新版本不好下载了，可能的平替是yt-dlp。

[github链接](https://github.com/yt-dlp/yt-dlp) [第三方手册](https://www.rapidseedbox.com/zh/blog/yt-dlp-complete-guide)

# 脚本说明

h264toh265_location_240626.py，主要使用这个进行压缩转码吧，这个功能完整一些。详细说明在文件里。

## 转码实测

原始视频：EVCapture4.1.6软件录制的443MB录屏。

libx265，-preset默认（medium)：124MB

libx265，-preset veryslow：131MB

默认-preset参数够用。


实测使用Nvidia的硬件加速，hevc_nvenc进行转码的话，速度很快。但是质量不佳，对比libx265，当时的实测文件，要大了一倍。所以倾向于使用libx265，即使使用CPU的效率不佳。
