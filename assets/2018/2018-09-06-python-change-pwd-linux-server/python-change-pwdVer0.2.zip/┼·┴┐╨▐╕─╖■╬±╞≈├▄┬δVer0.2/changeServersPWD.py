import paramiko
import sys
import os

# 获取服务器配置文件的文件名
file_name = input("请输入文件名（包含后缀如'servers.txt'），若不输入则默认读取'servers.txt'中的服务器信息：")
if file_name == '':
    file_name = sys.path[0]+'\\servers.txt'
else:
    file_name = sys.path[0]+'\\'+file_name

# 判断文件是否存在
if os.path.exists(file_name):
    pass
else:
    input("当前目录下不存在该文件，回车后程序结束")
    exit()

# 打开文件
with open(file_name, 'r', encoding='utf-8') as f:

    for i in f:
        L = i.split()
        host_name = L[0]
        port = L[1]
        root = L[2]
        root_pwd = L[3]
        user_name = L[4]
        user_pwd = L[5]

        # 创建SSH对象
        ssh = paramiko.SSHClient()
        try:
            # 允许连接不在known_hosts文件上的主机
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            # 连接服务器
            ssh.connect(hostname=host_name, port=port, username=root, password=root_pwd, timeout=5)
            # 执行命令
            stdin, stdout, stderr = ssh.exec_command('echo "%s" | passwd --stdin %s' % (user_pwd, user_name))
            # 获取结果
            result = stdout.read().decode()
            # 获取错误提示（stdout、stderr只会输出其中一个）
            err = stderr.read()
            # 关闭连接
            ssh.close()
            # 打印提示消息
            print(host_name,"KO! change <",user_name,">'s password successful!")
            print("执行结果：", stdin, result, err)
        except Exception as e:
            # 关闭连接
            ssh.close()
            # 打印错误消息
            print(host_name, str(e))

input("执行完毕，回车后关闭当前窗口")