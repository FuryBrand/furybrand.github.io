# 环境依赖

- python 3
- paramiko

# 扩展包的安装方式

``pip install paramiko``

# 使用方式

- 修改*servers.txt*文件。每一行对应一台服务器。共6个字段，分别对应*服务器地址*，*ssh端口号*，*root用户名*，*root密码*，*需要修改密码的用户名*，*需要修改的新密码*。
- 利用python launcher执行*changeServersPWD.py*文件。（如果没有更改配置的话，应该是双击就可以）


